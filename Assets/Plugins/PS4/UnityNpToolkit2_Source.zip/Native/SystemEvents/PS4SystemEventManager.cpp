#if defined(GLOBAL_EVENT_QUEUE)

#include "../Source/MainNPT.h"
#include "../PlayerInterface/UnityEventQueue.h"

#include "PS4SystemEvents.h"
#include "PS4SystemEventManager.h"

#include "../Source/Matching.h"
#include "../Source/Messaging.h"

namespace UnityPlugin
{
	UnityEventQueue::ClassBasedEventHandler<PS4OnResume, PS4SystemEventManager>								g_OnResumeAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnGameLiveStreamingStatusUpdate, PS4SystemEventManager>      g_OnGameLiveStreamingStatusUpdate;
	UnityEventQueue::ClassBasedEventHandler<PS4OnSessionInvitation, PS4SystemEventManager>                  g_OnSessionInvitationAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnEntitlementUpdate, PS4SystemEventManager>                  g_OnEntitlementUpdateAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnGameCustomData, PS4SystemEventManager>                     g_OnGameCustomDataAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnDisplaySafeAreaUpdate, PS4SystemEventManager>              g_OnDisplaySafeAreaUpdateAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnUrlOpen, PS4SystemEventManager>                            g_OnUrlOpenAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnLaunchApp, PS4SystemEventManager>                          g_OnLaunchAppAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnLaunchLink, PS4SystemEventManager>                         g_OnLaunchLinkAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnAddcontentInstall, PS4SystemEventManager>                  g_OnAddcontentInstallAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnResetVrPosition, PS4SystemEventManager>                    g_OnResetVrPositionAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnJoinEvent, PS4SystemEventManager>                          g_OnJoinEventAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnPlaygoLocusUpdate, PS4SystemEventManager>                  g_OnPlaygoLocusUpdateAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnOpenShareMenu, PS4SystemEventManager>                      g_OnOpenShareMenuAdapter;
	UnityEventQueue::ClassBasedEventHandler<PS4OnPlayTogetherHost, PS4SystemEventManager>                   g_OnPlayTogetherHostAdapter;

	void PS4SystemEventManager::Initialize(UnityEventQueue::IEventQueue* eventQueue)
	{
		m_EventQueue = eventQueue;

		if (m_EventQueue)
		{
			m_EventQueue->AddHandler(g_OnResumeAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnGameLiveStreamingStatusUpdate.SetObject(this));
			m_EventQueue->AddHandler(g_OnSessionInvitationAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnEntitlementUpdateAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnGameCustomDataAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnDisplaySafeAreaUpdateAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnUrlOpenAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnLaunchAppAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnLaunchLinkAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnAddcontentInstallAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnResetVrPositionAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnJoinEventAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnPlaygoLocusUpdateAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnOpenShareMenuAdapter.SetObject(this));
			m_EventQueue->AddHandler(g_OnPlayTogetherHostAdapter.SetObject(this));
		}
	}

	void PS4SystemEventManager::Shutdown()
	{
		if (m_EventQueue)
		{
			m_EventQueue->RemoveHandler(&g_OnResumeAdapter);
			m_EventQueue->RemoveHandler(&g_OnGameLiveStreamingStatusUpdate);
			m_EventQueue->RemoveHandler(&g_OnSessionInvitationAdapter);
			m_EventQueue->RemoveHandler(&g_OnEntitlementUpdateAdapter);
			m_EventQueue->RemoveHandler(&g_OnGameCustomDataAdapter);
			m_EventQueue->RemoveHandler(&g_OnDisplaySafeAreaUpdateAdapter);
			m_EventQueue->RemoveHandler(&g_OnUrlOpenAdapter);
			m_EventQueue->RemoveHandler(&g_OnLaunchAppAdapter);
			m_EventQueue->RemoveHandler(&g_OnLaunchLinkAdapter);
			m_EventQueue->RemoveHandler(&g_OnAddcontentInstallAdapter);
			m_EventQueue->RemoveHandler(&g_OnResetVrPositionAdapter);
			m_EventQueue->RemoveHandler(&g_OnJoinEventAdapter);
			m_EventQueue->RemoveHandler(&g_OnPlaygoLocusUpdateAdapter);
			m_EventQueue->RemoveHandler(&g_OnOpenShareMenuAdapter);
			m_EventQueue->RemoveHandler(&g_OnPlayTogetherHostAdapter);
		}
	}

	// System events...
	void PS4SystemEventManager::HandleEvent(PS4OnResume& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnResume\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnGameLiveStreamingStatusUpdate& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnGameLiveStreamingStatusUpdate\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnSessionInvitation& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnSessionInvitation\n");
		SceNpSessionInvitationEventParam* eventParam = (SceNpSessionInvitationEventParam*)&data.params.data;
		NPT::Matching::HandleSessionInvitationEvent(eventParam);
	}

	void PS4SystemEventManager::HandleEvent(PS4OnEntitlementUpdate& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnEntitlementUpdate\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnGameCustomData& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnGameCustomData\n");

		SceNpGameCustomDataEventParam* eventParam = (SceNpGameCustomDataEventParam*)&data.params.data;
		
		NPT::Messaging::HandleGameCustomDataEvent(eventParam);
	}

	void PS4SystemEventManager::HandleEvent(PS4OnDisplaySafeAreaUpdate& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnDisplaySafeAreaUpdate\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnUrlOpen& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnUrlOpen\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnLaunchApp& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnLaunchApp\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnLaunchLink& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnLaunchLink\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnAddcontentInstall& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnAddcontentInstall\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnResetVrPosition& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnResetVrPosition\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnJoinEvent& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnJoinEvent\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnPlaygoLocusUpdate& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnPlaygoLocusUpdate\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnOpenShareMenu& data)
	{
		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnOpenShareMenu\n");
	}

	void PS4SystemEventManager::HandleEvent(PS4OnPlayTogetherHost& data)
	{
		SceSystemServiceEvent* sEvent = (SceSystemServiceEvent*)&data;

		UNITY_TRACE("PS4SystemEventManager::HandleEvent: PS4OnPlayTogetherHost\n");
		#if (SCE_ORBIS_SDK_VERSION>0x03500000u)
		if ( sEvent->eventType == SCE_SYSTEM_SERVICE_EVENT_PLAY_TOGETHER_HOST )
		{
			// Don't handle this event as this the old version without the SceNpAccountId array.
			// The newer SCE_SYSTEM_SERVICE_EVENT_PLAY_TOGETHER_HOST_A event will occor after this one. 
			//SceNpPlayTogetherHostEventParam* eventParam = (SceNpPlayTogetherHostEventParam*)&data.params.data;
		}
		#endif

		#if (SCE_ORBIS_SDK_VERSION>0x04000000u)
		if ( sEvent->eventType == SCE_SYSTEM_SERVICE_EVENT_PLAY_TOGETHER_HOST_A )
		{
			SceNpPlayTogetherHostEventParamA* eventParam = (SceNpPlayTogetherHostEventParamA*)&data.params.data;
			NPT::Matching::HandlePlayTogetherHostEvent(eventParam);
		}

		#endif
	}

	// App events...
}
#endif
