#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class TssGetDataManaged : public RequestBaseManaged
	{
	public:

		UInt64					offset;             /// The byte offset where to start retieving the data
		UInt64					length;             /// The length of the block of memory to retrieve. 
		SceRtcTick              lastModified;     /// Uint64 - Optional paramter to test when data was last modified and not to return it unless it has changed.       
		SceNpTssSlotId			slotId;				///< The Slot ID on the TSS server to retrieve data from
		bool					retrieveStatusOnly;	///< If true, only the TSS data status is retrieved. The data buffer will be NULL
	
		void CopyTo(NpToolkit2::TSS::Request::GetData &destination);
	};	

	class TSS
	{
	public:

		typedef NpToolkit2::TSS::TssData NptTssData;
		typedef NpToolkit2::Core::Response<NptTssData> NptTssDataResponse;

		//Requests
		static int GetData(TssGetDataManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalTssData(NptTssDataResponse* response, MemoryBuffer& buffer, APIResult* result);
	};
}





