
#include "Trophies.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxRegisterTrophyPack ) (RegisterTrophyPackManaged* managedRequest, APIResult* result)
	{
		return Trophies::RegisterTrophyPack(managedRequest, result);
	}

	DO_EXPORT( int, PrxUnlockTrophy ) (UnlockTrophyManaged* managedRequest, APIResult* result)
	{
		return Trophies::UnlockTrophy(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetScreenshot ) (SetScreenshotManaged* managedRequest, APIResult* result)
	{
		return Trophies::SetScreenshot(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetUnlockedTrophies ) (GetUnlockedTrophiesManaged* managedRequest, APIResult* result)
	{
		return Trophies::GetUnlockedTrophies(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayTrophyListDialog ) (DisplayTrophyListDialogManaged* managedRequest, APIResult* result)
	{
		return Trophies::DisplayTrophyListDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetTrophyPackSummary ) (GetTrophyPackSummaryManaged* managedRequest, APIResult* result)
	{
		return Trophies::GetTrophyPackSummary(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetTrophyPackGroup ) (GetTrophyPackGroupManaged* managedRequest, APIResult* result)
	{
		return Trophies::GetTrophyPackGroup(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetTrophyPackTrophy ) (GetTrophyPackTrophyManaged* managedRequest, APIResult* result)
	{
		return Trophies::GetTrophyPackTrophy(managedRequest, result);
	}

	void RegisterTrophyPackManaged::CopyTo(NpToolkit2::Trophy::Request::RegisterTrophyPack &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void UnlockTrophyManaged::CopyTo(NpToolkit2::Trophy::Request::Unlock &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.trophyId = trophyId;
	}

	void SetScreenshotManaged::CopyTo(NpToolkit2::Trophy::Request::SetScreenshot &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
				
		destination.assignToAllUsers = assignToAllUsers; ///< True by default. Specify if the screenshot taken should be associated with all logged in users for the trophies specified in the <i><c>trophiesIds</c></i> array 
		destination.numTrophiesIds = MAX_SCREENSHOT_TROPHIES; ///< The number of valid elements in the <i><c>trophiesIds</c></i> array  

		if ( numTrophiesIds > 4 )
		{
			destination.numTrophiesIds = MAX_SCREENSHOT_TROPHIES;
		}

		for(int i = 0; i < destination.numTrophiesIds; i++)
		{
			destination.trophiesIds[i] = trophiesIds[i];   ///< An array with the trophy Ids to be assigned to the screenshot once it is taken. A maximum of <c>MAX_NUMBER_TROPHIES</c>
		}
	}

	void GetUnlockedTrophiesManaged::CopyTo(NpToolkit2::Trophy::Request::GetUnlockedTrophies &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void DisplayTrophyListDialogManaged::CopyTo(NpToolkit2::Trophy::Request::DisplayTrophyListDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

	}

	void GetTrophyPackSummaryManaged::CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackSummary &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.retrieveTrophyPackSummaryIcon = retrieveTrophyPackSummaryIcon;			
	}

	void GetTrophyPackGroupManaged::CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackGroup &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.groupId = groupId;					                            ///< The group to return the information from
		destination.retrieveTrophyPackGroupIcon = retrieveTrophyPackGroupIcon;		///< False by default. Set it to true to return the icon for the group
	}

	void GetTrophyPackTrophyManaged::CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackTrophy &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.trophyId = trophyId;						///< The trophy to return the information from
		destination.retrieveTrophyPackTrophyIcon = retrieveTrophyPackTrophyIcon;			///< False by default. Set it to true to return the icon for the trophy 
	}
	
	int Trophies::RegisterTrophyPack(RegisterTrophyPackManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Trophy::Request::RegisterTrophyPack nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::registerTrophyPack(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}


	int Trophies::UnlockTrophy(UnlockTrophyManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Trophy::Request::Unlock nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::unlock(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Trophies::SetScreenshot(SetScreenshotManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Trophy::Request::SetScreenshot nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::setScreenshot(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}


	int Trophies::GetUnlockedTrophies(GetUnlockedTrophiesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptUnlockedTrophiesResponse* nptResponse = new NptUnlockedTrophiesResponse();

		NpToolkit2::Trophy::Request::GetUnlockedTrophies nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::getUnlockedTrophies(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Trophies::DisplayTrophyListDialog(DisplayTrophyListDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Trophy::Request::DisplayTrophyListDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::displayTrophyListDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Trophies::GetTrophyPackSummary(GetTrophyPackSummaryManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTrophyPackSummaryResponse* nptResponse = new NptTrophyPackSummaryResponse();

		NpToolkit2::Trophy::Request::GetTrophyPackSummary nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::getTrophyPackSummary(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Trophies::GetTrophyPackGroup(GetTrophyPackGroupManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTrophyPackGroupResponse* nptResponse = new NptTrophyPackGroupResponse();

		NpToolkit2::Trophy::Request::GetTrophyPackGroup nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::getTrophyPackGroup(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Trophies::GetTrophyPackTrophy(GetTrophyPackTrophyManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTrophyPackTrophyResponse* nptResponse = new NptTrophyPackTrophyResponse();

		NpToolkit2::Trophy::Request::GetTrophyPackTrophy nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Trophy::getTrophyPackTrophy(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}



	// Sce Write method	
	void Trophies::WriteToBuffer(const SceNpTrophyGameDetails& sceNpTrophyGameDetails, MemoryBuffer& buffer)
	{
		buffer.WriteUInt32(sceNpTrophyGameDetails.numGroups);
		buffer.WriteUInt32(sceNpTrophyGameDetails.numTrophies);
		buffer.WriteUInt32(sceNpTrophyGameDetails.numPlatinum);
		buffer.WriteUInt32(sceNpTrophyGameDetails.numGold);
		buffer.WriteUInt32(sceNpTrophyGameDetails.numSilver);
		buffer.WriteUInt32(sceNpTrophyGameDetails.numBronze);

		buffer.WriteString(sceNpTrophyGameDetails.title);
		buffer.WriteString(sceNpTrophyGameDetails.description);
	}

	void Trophies::WriteToBuffer(const SceNpTrophyGameData& sceNpTrophyGameData, MemoryBuffer& buffer)
	{
		buffer.WriteUInt32(sceNpTrophyGameData.unlockedTrophies);
		buffer.WriteUInt32(sceNpTrophyGameData.unlockedPlatinum);
		buffer.WriteUInt32(sceNpTrophyGameData.unlockedGold);
		buffer.WriteUInt32(sceNpTrophyGameData.unlockedSilver);
		buffer.WriteUInt32(sceNpTrophyGameData.unlockedBronze);
		buffer.WriteUInt32(sceNpTrophyGameData.progressPercentage);
	}

	void Trophies::WriteToBuffer(const SceNpTrophyGroupDetails& sceNpTrophyGroupDetails, MemoryBuffer& buffer)
	{
		buffer.WriteInt32(sceNpTrophyGroupDetails.groupId);
		buffer.WriteUInt32(sceNpTrophyGroupDetails.numTrophies);
		buffer.WriteUInt32(sceNpTrophyGroupDetails.numPlatinum);
		buffer.WriteUInt32(sceNpTrophyGroupDetails.numGold);
		buffer.WriteUInt32(sceNpTrophyGroupDetails.numSilver);
		buffer.WriteUInt32(sceNpTrophyGroupDetails.numBronze);

		buffer.WriteString(sceNpTrophyGroupDetails.title);
		buffer.WriteString(sceNpTrophyGroupDetails.description);
	}

	void Trophies::WriteToBuffer(const SceNpTrophyGroupData& sceNpTrophyGroupData, MemoryBuffer& buffer)
	{
		buffer.WriteInt32(sceNpTrophyGroupData.groupId);
		buffer.WriteUInt32(sceNpTrophyGroupData.unlockedTrophies);
		buffer.WriteUInt32(sceNpTrophyGroupData.unlockedPlatinum);
		buffer.WriteUInt32(sceNpTrophyGroupData.unlockedGold);
		buffer.WriteUInt32(sceNpTrophyGroupData.unlockedSilver);
		buffer.WriteUInt32(sceNpTrophyGroupData.unlockedBronze);
		buffer.WriteUInt32(sceNpTrophyGroupData.progressPercentage);
	}

	void Trophies::WriteToBuffer(const SceNpTrophyDetails& sceNpTrophyDetails, MemoryBuffer& buffer)
	{
		buffer.WriteInt32(sceNpTrophyDetails.trophyId);
		buffer.WriteInt32(sceNpTrophyDetails.trophyGrade);   // SCE_NP_TROPHY_GRADE_XXX
		buffer.WriteInt32(sceNpTrophyDetails.groupId);
		buffer.WriteBool(sceNpTrophyDetails.hidden);

		buffer.WriteString(sceNpTrophyDetails.name);
		buffer.WriteString(sceNpTrophyDetails.description);
	}

	void Trophies::WriteToBuffer(const SceNpTrophyData& sceNpTrophyData, MemoryBuffer& buffer)
	{
		buffer.WriteInt32(sceNpTrophyData.trophyId);
		buffer.WriteBool(sceNpTrophyData.unlocked);
		Core::WriteToBuffer(sceNpTrophyData.timestamp, buffer);   // SceRtcTick
	}

	// Marshal methods
	void Trophies::MarshalUnlockedTrophies(NptUnlockedTrophiesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::UnlockedTrophiesBegin);

		const NptUnlockedTrophies* unlockedTrophies = response->get();

		buffer.WriteUInt32(unlockedTrophies->numTrophiesIds);

		for(int i = 0; i < unlockedTrophies->numTrophiesIds; i++)
		{
			buffer.WriteInt32(unlockedTrophies->trophiesIds[i]);
		}

		buffer.WriteMarker(BufferIntegrityChecks::UnlockedTrophiesEnd);

		SUCCESS_RESULT(result);
	}

	void Trophies::MarshalTrophyPackSummary(NptTrophyPackSummaryResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackSummaryBegin);

		const NptTrophyPackSummary* trophyPackSummary = response->get();

		PNGWriter::WriteToBuffer(trophyPackSummary->icon, (Int32)trophyPackSummary->iconSize, buffer);  ///< The icon retrieved in case it was explicitely specified in the request		

		WriteToBuffer(trophyPackSummary->staticConfiguration, buffer);
		WriteToBuffer(trophyPackSummary->userProgress, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackSummaryEnd);

		SUCCESS_RESULT(result);
	}

	void  Trophies::MarshalTrophyPackGroup(NptTrophyPackGroupResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackGroupBegin);

		const NptTrophyPackGroup* trophyPackGroup = response->get();

		PNGWriter::WriteToBuffer(trophyPackGroup->icon, (Int32)trophyPackGroup->iconSize, buffer);  ///< The icon retrieved in case it was explicitely specified in the request

		WriteToBuffer(trophyPackGroup->staticConfiguration, buffer);
		WriteToBuffer(trophyPackGroup->userProgress, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackGroupEnd);

		SUCCESS_RESULT(result);
	}

	void  Trophies::MarshalTrophyPackTrophy(NptTrophyPackTrophyResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackTrophyBegin);

		const NptTrophyPackTrophy* trophyPackTrophy = response->get();

		PNGWriter::WriteToBuffer(trophyPackTrophy->icon, (Int32)trophyPackTrophy->iconSize, buffer);   ///< The icon retrieved in case it was explicitely specified in the request

		WriteToBuffer(trophyPackTrophy->staticConfiguration, buffer);
		WriteToBuffer(trophyPackTrophy->userProgress, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::TrophyPackTrophyEnd);

		SUCCESS_RESULT(result);
	}

}
