
#include "Matching.h"

#include "Core.h"
#include "NetworkUtils.h"

namespace NPT
{
	DO_EXPORT( int, PrxSetInitConfiguration ) (SetInitConfigurationManaged* managedRequest, APIResult* result)
	{
		return Matching::SetInitConfiguration(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetWorlds ) (GetWorldsManaged* managedRequest, APIResult* result)
	{
		return Matching::GetWorlds(managedRequest, result);
	}

	DO_EXPORT( int, PrxCreateRoom ) (CreateRoomManaged* managedRequest, APIResult* result)
	{
		return Matching::CreateRoom(managedRequest, result);
	}

	DO_EXPORT( int, PrxLeaveRoom ) (LeaveRoomManaged* managedRequest, APIResult* result)
	{
		return Matching::LeaveRoom(managedRequest, result);
	}

	DO_EXPORT( int, PrxSearchRooms ) (SearchRoomsManaged* managedRequest, APIResult* result)
	{
		return Matching::SearchRooms(managedRequest, result);
	}

	DO_EXPORT( int, PrxJoinRoom ) (JoinRoomManaged* managedRequest, APIResult* result)
	{
		return Matching::JoinRoom(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetRoomPingTime ) (GetRoomPingTimeManaged* managedRequest, APIResult* result)
	{
		return Matching::GetRoomPingTime(managedRequest, result);
	}

	DO_EXPORT( int, PrxKickOutRoomMember ) (KickOutRoomMemberManaged* managedRequest, APIResult* result)
	{
		return Matching::KickOutRoomMember(managedRequest, result);
	}

	DO_EXPORT( int, PrxSendRoomMessage ) (SendRoomMessageManaged* managedRequest, APIResult* result)
	{
		return Matching::SendRoomMessage(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetAttributes ) (GetAttributesManaged* managedRequest, APIResult* result)
	{
		return Matching::GetAttributes(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetData ) (GetDataManaged* managedRequest, APIResult* result)
	{
		return Matching::GetData(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetRoomInfo ) (SetRoomInfoManaged* managedRequest, APIResult* result)
	{
		return Matching::SetRoomInfo(managedRequest, result);
	}

	DO_EXPORT( int, PrxSendInvitation ) (SendInvitationManaged* managedRequest, APIResult* result)
	{
		return Matching::SendInvitation(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetMembersAsRecentlyMet ) (SetMembersAsRecentlyMetManaged* managedRequest, APIResult* result) // SDK 4.5
	{
		return Matching::SetMembersAsRecentlyMet(managedRequest, result);
	}

	void AttributeMetadataManaged::CopyTo(NpToolkit2::Matching::AttributeMetadata &destination)
	{
		strcpy_s(destination.name, NpToolkit2::Matching::AttributeMetadata::MAX_SIZE_NAME+1, name);
		destination.type = type;
		destination.scope = scope;
		destination.roomAttributeVisibility = roomAttributeVisibility;
		destination.size = size;
	}

	void AttributeManaged::CopyTo(NpToolkit2::Matching::Attribute &destination)
	{
		metadata.CopyTo(destination.metadata);

		if ( metadata.type == NpToolkit2::Matching::AttributeType::integer )
		{
			destination.intValue = intValue;
		}
		else
		{
			memcpy_s(destination.binValue, NpToolkit2::Matching::Attribute::MAX_SIZE_BIN_VALUE, binValue, metadata.size);
		}
	}

	void SessionImageManaged::CopyTo(NpToolkit2::Session::SessionImage &destination)
	{
		strcpy_s(destination.sessionImgPath, NpToolkit2::Session::SessionImage::IMAGE_PATH_MAX_LEN + 1, sessionImgPath);
	}

	void LocalizedSessionInfoManaged::CopyTo(NpToolkit2::Matching::LocalizedSystemInfo &destination)
	{
		strcpy_s(destination.sessionName, NpToolkit2::Session::LocalizedSessionInfo::SESSION_NAME_LEN + 1, sessionName);
		strcpy_s(destination.status, NpToolkit2::Session::LocalizedSessionInfo::STATUS_LEN + 1, status);

		strcpy_s(destination.languageCode.code, SCE_NP_LANGUAGE_CODE_MAX_LEN + 1, languageCode);	
	}

	void SetInitConfigurationManaged::CopyTo(NpToolkit2::Matching::Request::SetInitConfiguration &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.attributes = new NpToolkit2::Matching::AttributeMetadata[numAttributes];;
		destination.numAttributes = numAttributes;

		for(UInt64 i =0; i < numAttributes; i++)
		{
			attributes[i].CopyTo(destination.attributes[i]);
		}
	}

	void GetWorldsManaged::CopyTo(NpToolkit2::Matching::Request::GetWorlds &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}

	void CreateRoomManaged::CopyTo(NpToolkit2::Matching::Request::CreateRoom &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.numAttributes = numAttributes;
		destination.attributes =  NULL;

		if ( numAttributes > 0 )
		{
			destination.attributes = new NpToolkit2::Matching::Attribute[numAttributes];
		}

		for(UInt64 i =0; i < numAttributes; i++)
		{
			attributes[i].CopyTo(destination.attributes[i]);
		}

		strcpy_s(destination.name, NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_ROOM_NAME + 1, name);

		strcpy_s((char*)destination.password.data, SCE_NP_MATCHING2_SESSION_PASSWORD_SIZE, password);

		destination.visibility = visibility;
		destination.numReservedSlots = numReservedSlots;

		destination.fixedDataSize = fixedDataSize;
		destination.fixedData = NULL;

		if ( fixedDataSize > 0 && fixedData != NULL )
		{
			destination.fixedData = new UInt8[fixedDataSize];
			memcpy(destination.fixedData, fixedData, fixedDataSize); 
		}

		destination.changeableDataSize = changeableDataSize;
		destination.changeableData = NULL;

		if ( changeableDataSize > 0 && changeableData != NULL )
		{
			destination.changeableData = new UInt8[changeableDataSize];
			memcpy(destination.changeableData, changeableData, changeableDataSize); 
		}
		
		strcpy_s(destination.status, NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_ROOM_STATUS + 1, status);

		for(UInt64 i =0; i < NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_LOCALIZATIONS; i++)
		{
			localizations[i].CopyTo(destination.localizations[i]);
		}

		image.CopyTo(destination.image);

		destination.displayOnSystem = displayOnSystem;
		destination.isSystemJoinable = isSystemJoinable;
		destination.joinAllLocalUsers = joinAllLocalUsers;
		destination.isNatRestricted = isNatRestricted;
		destination.ownershipMigration = ownershipMigration;
		destination.topology = topology;
		destination.maxNumMembers = maxNumMembers;
		destination.worldNumber = worldNumber;

		destination.isCrossplatform = isCrossplatform;
		destination.allowBlockedUsersOfOwner = allowBlockedUsersOfOwner;
		destination.allowBlockedUsersOfMembers = allowBlockedUsersOfMembers;
	}

	class CreateRoomCleanup : public RequestCleanup<NpToolkit2::Matching::Request::CreateRoom>
	{
	public:

		CreateRoomCleanup(NpToolkit2::Matching::Request::CreateRoom* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Matching::Request::CreateRoom* request = GetRequest();

			if ( request->attributes != NULL )
			{
				delete[] request->attributes;
			}

			if ( request->fixedData != NULL )
			{
				delete[] (UInt8*)request->fixedData;
			}

			if ( request->changeableData != NULL )
			{
				delete[] (UInt8*)request->changeableData;
			}
		}
	};

	void MatchingPresenceOptionDataManaged::CopyTo(SceNpMatching2PresenceOptionData &destination)
	{
		memcpy(destination.data, data, SCE_NP_MATCHING2_PRESENCE_OPTION_DATA_SIZE);
		destination.len = length;
	};

	void LeaveRoomManaged::CopyTo(NpToolkit2::Matching::Request::LeaveRoom &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;
		notificationDataToMembers.CopyTo(destination.notificationDataToMembers);
	}


	void SearchClauseManaged::CopyTo(NpToolkit2::Matching::Request::SearchClause &destination)
	{
		attributeToCompare.CopyTo(destination.attributeToCompare);
		destination.operatorType = operatorType;
	}

	void SearchRoomsManaged::CopyTo(NpToolkit2::Matching::Request::SearchRooms &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.numSearchClauses = numSearchClauses;

		if ( numSearchClauses > 0 )
		{
			destination.searchClauses = new NpToolkit2::Matching::Request::SearchClause[numSearchClauses];

			for(int i = 0; i < numSearchClauses; i++)
			{
				searchClauses[i].CopyTo(destination.searchClauses[i]);
			}
		}

		destination.numUsersToSearchInRooms = numUsersToSearchInRooms;
		destination.usersToSearchInRooms = NULL;

		if ( numUsersToSearchInRooms > 0 )
		{
			destination.usersToSearchInRooms = new SceNpAccountId[numUsersToSearchInRooms];

			for(int i = 0; i < numUsersToSearchInRooms; i++)
			{
				destination.usersToSearchInRooms[i] = usersToSearchInRooms[i];
			}
		}

		destination.offset = offset;
		destination.pageSize = pageSize;

		destination.searchScope = searchScope;
		destination.worldNumber = worldNumber;

		destination.provideRandomRooms = provideRandomRooms;
		destination.quickJoin = quickJoin;
		destination.applyNatTypeFilter = applyNatTypeFilter;
	}

	class SearchRoomsCleanup : public RequestCleanup<NpToolkit2::Matching::Request::SearchRooms>
	{
	public:

		SearchRoomsCleanup(NpToolkit2::Matching::Request::SearchRooms* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Matching::Request::SearchRooms* request = GetRequest();

			if ( request->searchClauses != NULL )
			{
				delete[] request->searchClauses;
			}

			if ( request->usersToSearchInRooms != NULL )
			{
				delete[] request->usersToSearchInRooms;
			}
		}
	};

	void SessionIdManaged::CopyTo(SceNpSessionId &destination)
	{
		strcpy_s(destination.data, SCE_NP_SESSION_ID_MAX_SIZE, data);
	}

	void JoinRoomManaged::CopyTo(NpToolkit2::Matching::Request::JoinRoom &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		strcpy_s((char*)destination.password.data, SCE_NP_MATCHING2_SESSION_PASSWORD_SIZE, password);

		destination.numMemberAttributes = numMemberAttributes;
		destination.memberAttributes =  NULL;

		if ( numMemberAttributes > 0 )
		{
			destination.memberAttributes = new NpToolkit2::Matching::Attribute[numMemberAttributes];

			for(UInt64 i =0; i < numMemberAttributes; i++)
			{
				memberAttributes[i].CopyTo(destination.memberAttributes[i]);
			}
		}

		notificationDataToMembers.CopyTo(destination.notificationDataToMembers);

		destination.roomId = roomId;

		boundSessionId.CopyTo(destination.boundSessionId);

		destination.identifyRoomBy = identifyRoomBy;

		destination.joinAllLocalUsers = joinAllLocalUsers;
		destination.allowBlockedUsers = allowBlockedUsers;	
	}

	void GetRoomPingTimeManaged::CopyTo(NpToolkit2::Matching::Request::GetRoomPingTime &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;
	}

	void SendInvitationManaged::CopyTo(NpToolkit2::Matching::Request::SendInvitation &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;

		destination.numRecipients = numRecipients;

		for(int i = 0; i < numRecipients; i++)
		{
			destination.recipients[i] = recipients[i];
		}
	
		strcpy_s(destination.userMessage, NpToolkit2::Matching::Request::SendInvitation::MAX_SIZE_USER_MESSAGE + 1, userMessage);

		destination.attachmentSize = attachmentSize;
		destination.attachment = NULL;

		if ( attachmentSize > 0 )
		{
			destination.attachment = new char[attachmentSize];
			memcpy(destination.attachment, attachment, attachmentSize);
		}

		destination.maxNumberRecipientsToAdd = maxNumberRecipientsToAdd;
		destination.recipientsEditableByUser = recipientsEditableByUser;
		destination.enableDialog = enableDialog;
	}

	class SendInvitationCleanup : public RequestCleanup<NpToolkit2::Matching::Request::SendInvitation>
	{
	public:

		SendInvitationCleanup(NpToolkit2::Matching::Request::SendInvitation* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Matching::Request::SendInvitation* request = GetRequest();

			if ( request->attachment != NULL )
			{
				delete[] request->attachment;
			}
		}
	};

	void KickOutRoomMemberManaged::CopyTo(NpToolkit2::Matching::Request::KickOutRoomMember &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;

		notificationDataToMembers.CopyTo(destination.notificationDataToMembers);

		destination.memberId = memberId;
		destination.allowRejoin = allowRejoin;
	}

	void SendRoomMessageManaged::CopyTo(NpToolkit2::Matching::Request::SendRoomMessage &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;

		destination.numMembers = numMembers;

		if ( numMembers > 0 )
		{
			destination.members = new UInt16[numMembers];

			for(int i = 0; i < numMembers; i++)
			{
				destination.members[i] = members[i];
			}
		}
		
		destination.dataSize = dataSize;

		memcpy_s(destination.data, NpToolkit2::Matching::Request::SendRoomMessage::MESSAGE_MAX_SIZE + 1, data, dataSize);

		destination.isChatMsg = isChatMsg;
	}

	class SendRoomMessageCleanup : public RequestCleanup<NpToolkit2::Matching::Request::SendRoomMessage>
	{
	public:

		SendRoomMessageCleanup(NpToolkit2::Matching::Request::SendRoomMessage* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Matching::Request::SendRoomMessage* request = GetRequest();

			if ( request->members != NULL )
			{
				delete[] request->members;
			}
		}
	};

	void GetAttributesManaged::CopyTo(NpToolkit2::Matching::Request::GetAttributes &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;
		destination.scope = scope;

		if ( scope == NpToolkit2::Matching::AttributeScope::room )
		{
			destination.roomAttributeVisibility = roomAttributeVisibility;
		}
		else
		{
			destination.memberId = memberId;
		}
	}

	void GetDataManaged::CopyTo(NpToolkit2::Matching::Request::GetData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;
		destination.type = type;
	}

	void SetRoomInfoManaged::CopyTo(NpToolkit2::Matching::Request::SetRoomInfo &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.roomId = roomId;
		destination.roomInfoType = roomInfoType;

		if ( roomInfoType == NpToolkit2::Matching::Request::SetRoomInfoType::memberInfo )
		{
			destination.memberInfo.memberId = memberInfo.memberId;
			destination.memberInfo.numMemberAttributes = memberInfo.numMemberAttributes;

			if ( memberInfo.numMemberAttributes > 0 )
			{
				destination.memberInfo.memberAttributes = new NpToolkit2::Matching::Attribute[memberInfo.numMemberAttributes];

				for(int i =0; i < memberInfo.numMemberAttributes; i++)
				{
					memberInfo.memberAttributes[i].CopyTo(destination.memberInfo.memberAttributes[i]);
				}
			}
		}
		else if ( roomInfoType == NpToolkit2::Matching::Request::SetRoomInfoType::roomExternalInfo )
		{
			destination.roomExternalInfo.numExternalAttributes = roomExternalInfo.numExternalAttributes;

			if ( roomExternalInfo.numExternalAttributes > 0 )
			{
				destination.roomExternalInfo.externalAttributes = new NpToolkit2::Matching::Attribute[roomExternalInfo.numExternalAttributes];

				for(int i =0; i < roomExternalInfo.numExternalAttributes; i++)
				{
					roomExternalInfo.externalAttributes[i].CopyTo(destination.roomExternalInfo.externalAttributes[i]);
				}
			}

			destination.roomExternalInfo.numSearchAttributes = roomExternalInfo.numSearchAttributes;

			if ( roomExternalInfo.numSearchAttributes > 0 )
			{
				destination.roomExternalInfo.searchAttributes = new NpToolkit2::Matching::Attribute[roomExternalInfo.numSearchAttributes];

				for(int i =0; i < roomExternalInfo.numSearchAttributes; i++)
				{
					roomExternalInfo.searchAttributes[i].CopyTo(destination.roomExternalInfo.searchAttributes[i]);
				}
			}
		}
		else if ( roomInfoType == NpToolkit2::Matching::Request::SetRoomInfoType::roomInternalInfo )
		{
			destination.roomInternalInfo.numInternalAttributes = roomInternalInfo.numInternalAttributes;

			if ( roomInternalInfo.numInternalAttributes > 0 )
			{
				destination.roomInternalInfo.internalAttributes = new NpToolkit2::Matching::Attribute[roomInternalInfo.numInternalAttributes];

				for(int i =0; i < roomInternalInfo.numInternalAttributes; i++)
				{
					roomInternalInfo.internalAttributes[i].CopyTo(destination.roomInternalInfo.internalAttributes[i]);
				}
			}

			destination.roomInternalInfo.allowBlockedUsersOfMembers = roomInternalInfo.allowBlockedUsersOfMembers;
			destination.roomInternalInfo.joinAllLocalUsers = roomInternalInfo.joinAllLocalUsers;
			destination.roomInternalInfo.isNatRestricted = roomInternalInfo.isNatRestricted;
			destination.roomInternalInfo.numReservedSlots = roomInternalInfo.numReservedSlots;
			destination.roomInternalInfo.visibility = roomInternalInfo.visibility;
			destination.roomInternalInfo.closeRoom = roomInternalInfo.closeRoom;
		}
		else if ( roomInfoType == NpToolkit2::Matching::Request::SetRoomInfoType::roomSessionInfo )
		{
			destination.roomSessionInfo.displayOnSystem = roomSessionInfo.displayOnSystem;
			destination.roomSessionInfo.isSystemJoinable = roomSessionInfo.isSystemJoinable;

			destination.roomSessionInfo.changeableDataSize = roomSessionInfo.changeableDataSize;

			if ( roomSessionInfo.changeableDataSize > 0 && roomSessionInfo.changeableData != NULL )
			{
				destination.roomSessionInfo.changeableData = new UInt8[roomSessionInfo.changeableDataSize];
				memcpy(destination.roomSessionInfo.changeableData, roomSessionInfo.changeableData, roomSessionInfo.changeableDataSize); 
			}

			strcpy_s(destination.roomSessionInfo.status, NpToolkit2::Matching::Request::CreateRoom::MAX_SIZE_ROOM_STATUS + 1, roomSessionInfo.status);

			destination.roomSessionInfo.numLocalizations = roomSessionInfo.numLocalizations;

			if ( roomSessionInfo.numLocalizations > 0  )
			{
				destination.roomSessionInfo.localizations = new NpToolkit2::Matching::LocalizedSystemInfo[roomSessionInfo.numLocalizations];

				for(UInt64 i =0; i < roomSessionInfo.numLocalizations; i++)
				{
					roomSessionInfo.localizations[i].CopyTo(destination.roomSessionInfo.localizations[i]);
				}
			}

			if ( strlen(roomSessionInfo.image.sessionImgPath) > 0 )
			{
				destination.roomSessionInfo.image = new NpToolkit2::Session::SessionImage();
				roomSessionInfo.image.CopyTo(*destination.roomSessionInfo.image);
			}
		}
		else if ( roomInfoType == NpToolkit2::Matching::Request::SetRoomInfoType::roomTopology )
		{
			destination.roomTopology = roomTopology;
		}
	}

	class SetRoomInfoCleanup : public RequestCleanup<NpToolkit2::Matching::Request::SetRoomInfo>
	{
	public:

		SetRoomInfoCleanup(NpToolkit2::Matching::Request::SetRoomInfo* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Matching::Request::SetRoomInfo* request = GetRequest();

			switch(request->roomInfoType)
			{
			case NpToolkit2::Matching::Request::SetRoomInfoType::memberInfo:
				{
					if ( request->memberInfo.memberAttributes != NULL )
					{
						delete[] request->memberInfo.memberAttributes;
					}
				}
				break;
			case NpToolkit2::Matching::Request::SetRoomInfoType::roomExternalInfo:
				{
					if ( request->roomExternalInfo.externalAttributes != NULL )
					{
						delete[] request->roomExternalInfo.externalAttributes;
						request->roomExternalInfo.externalAttributes = NULL;
					}

					if ( request->roomExternalInfo.searchAttributes != NULL )
					{
						delete[] request->roomExternalInfo.searchAttributes;
						request->roomExternalInfo.searchAttributes = NULL;
					}
				}
				break;
			case NpToolkit2::Matching::Request::SetRoomInfoType::roomInternalInfo:
				{
					if ( request->roomInternalInfo.internalAttributes != NULL )
					{
						delete[] request->roomInternalInfo.internalAttributes;
						request->roomInternalInfo.internalAttributes = NULL;
					}
				}
				break;
			case NpToolkit2::Matching::Request::SetRoomInfoType::roomSessionInfo:
				{
					if ( request->roomSessionInfo.changeableData != NULL )
					{
						delete[] (UInt8*)request->roomSessionInfo.changeableData;
						request->roomSessionInfo.changeableData = NULL;
					}

					if ( request->roomSessionInfo.localizations != NULL )
					{
						delete[] request->roomSessionInfo.localizations;
						request->roomSessionInfo.localizations = NULL;
					}

					if ( request->roomSessionInfo.image != NULL )
					{
						delete request->roomSessionInfo.image;
						request->roomSessionInfo.image = NULL;
					}
				}
				break;
			case NpToolkit2::Matching::Request::SetRoomInfoType::roomTopology:
				{

				}
				break;
			default:
				break;

			}
		}
	};

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	void SetMembersAsRecentlyMetManaged::CopyTo(NpToolkit2::Matching::Request::SetMembersAsRecentlyMet &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class
	}
#endif

	// Request methods
	int Matching::SetInitConfiguration(SetInitConfigurationManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::SetInitConfiguration nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::setInitConfiguration(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::GetWorlds(GetWorldsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptWorldsResponse* nptResponse = new NptWorldsResponse();

		NpToolkit2::Matching::Request::GetWorlds nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::getWorlds(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::CreateRoom(CreateRoomManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptRoomResponse* nptResponse = new NptRoomResponse();

		NpToolkit2::Matching::Request::CreateRoom* nptRequest = new NpToolkit2::Matching::Request::CreateRoom();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Matching::createRoom(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		CreateRoomCleanup* cleanup = new CreateRoomCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::LeaveRoom(LeaveRoomManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::LeaveRoom nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::leaveRoom(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::SearchRooms(SearchRoomsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptSearchRoomsResponse* nptResponse = new NptSearchRoomsResponse();

		NpToolkit2::Matching::Request::SearchRooms* nptRequest = new NpToolkit2::Matching::Request::SearchRooms();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Matching::searchRooms(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		SearchRoomsCleanup* cleanup = new SearchRoomsCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);
		
		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::JoinRoom(JoinRoomManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptRoomResponse* nptResponse = new NptRoomResponse();

		NpToolkit2::Matching::Request::JoinRoom nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::joinRoom(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::GetRoomPingTime(GetRoomPingTimeManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptRoomPingTimeResponse* nptResponse = new NptRoomPingTimeResponse();

		NpToolkit2::Matching::Request::GetRoomPingTime nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::getRoomPingTime(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::KickOutRoomMember(KickOutRoomMemberManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::KickOutRoomMember nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::kickOutRoomMember(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::SendRoomMessage(SendRoomMessageManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::SendRoomMessage* nptRequest = new NpToolkit2::Matching::Request::SendRoomMessage();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Matching::sendRoomMessage(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		SendRoomMessageCleanup* cleanup = new SendRoomMessageCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::GetAttributes(GetAttributesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptRefreshRoomResponse* nptResponse = new NptRefreshRoomResponse();

		NpToolkit2::Matching::Request::GetAttributes nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::getAttributes(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::SetRoomInfo(SetRoomInfoManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::SetRoomInfo* nptRequest = new NpToolkit2::Matching::Request::SetRoomInfo();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Matching::setRoomInfo(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
		
		SetRoomInfoCleanup* cleanup = new SetRoomInfoCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::SendInvitation(SendInvitationManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::SendInvitation* nptRequest = new NpToolkit2::Matching::Request::SendInvitation();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Matching::sendInvitation(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
		
		SendInvitationCleanup* cleanup = new SendInvitationCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::GetData(GetDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptGetDataResponse* nptResponse = new NptGetDataResponse();

		NpToolkit2::Matching::Request::GetData nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::getData(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
		
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Matching::SetMembersAsRecentlyMet(SetMembersAsRecentlyMetManaged* managedRequest, APIResult* result)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Matching::Request::SetMembersAsRecentlyMet nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Matching::setMembersAsRecentlyMet(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
		
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
#else
		SUCCESS_RESULT(result);
		return 0;
#endif
	}

	// Marshal responses
	void Matching::MarshalGetWorlds(NptWorldsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{			
		const NptWorlds* worlds = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::WorldsBegin);

		buffer.WriteUInt64(worlds->numWorlds);

		for(int i = 0; i < worlds->numWorlds; i++)
		{
			WriteToBuffer(worlds->worlds[i], buffer);
		}
		
		buffer.WriteMarker(BufferIntegrityChecks::WorldsEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalRoom(NptRoomResponse* response, MemoryBuffer& buffer, APIResult* result)
	{			
		const NptRoom* room = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::CreateRoomBegin);
		
		WriteToBuffer(*room, buffer);
		
		buffer.WriteMarker(BufferIntegrityChecks::CreateRoomEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalSearchRooms(NptSearchRoomsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{			
		const NptRooms* rooms = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::RoomsBegin);

		buffer.WriteUInt64(rooms->numRooms);

		for(int i = 0; i < rooms->numRooms; i++)
		{
			WriteToBuffer(rooms->rooms[i], buffer);
		}
		
		buffer.WriteMarker(BufferIntegrityChecks::RoomsEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalRoomPingTime(NptRoomPingTimeResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptRoomPingTime* roomPingTime = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::RoomPingTimeBegin);

		buffer.WriteUInt32(roomPingTime->roundTripTime);

		buffer.WriteMarker(BufferIntegrityChecks::RoomPingTimeEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalGetData(NptGetDataResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptGetData* getData = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::GetDataBegin);

		buffer.WriteUInt32((UInt32)getData->type);

		buffer.WriteData((char*)getData->data, getData->dataSize);

		buffer.WriteMarker(BufferIntegrityChecks::GetDataEnd);

		SUCCESS_RESULT(result);
	}

	// Notification
	void Matching::MarshalRefreshRoom(NptRefreshRoomResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptRefreshRoom* refreshRoom = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::RefreshRoomBegin);

		buffer.WriteUInt64(refreshRoom->roomId);

		WriteToBuffer(refreshRoom->notificationFromMember, buffer);

		buffer.WriteUInt32((UInt32)refreshRoom->reason);
		buffer.WriteUInt32(refreshRoom->cause);

		if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::memberJoined ||
			 refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::memberLeft ||
			 refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::memberSignalingUpdate ||
			 refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::memberInfoUpdated)
		{
			WriteToBuffer(*(refreshRoom->memberInfo), buffer);
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::ownerChanged )
		{
			WriteToBuffer(refreshRoom->ownerInfo.password, buffer);

			for(int i =0; i < NpToolkit2::Matching::Notification::RefreshRoom::OWNER_EXCHANGE_SIZE; i++)
			{
				buffer.WriteUInt16(refreshRoom->ownerInfo.oldAndNewOwners[i]);
			}
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomDestroyed ||
			      refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomKickedOut )
		{
			buffer.WriteInt64(refreshRoom->roomLeftError);		
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomExternalInfoUpdated )
		{
			buffer.WriteUInt64(refreshRoom->roomExternalInfo.numAttributes);

			for(int i = 0; i < refreshRoom->roomExternalInfo.numAttributes; i++)
			{
				WriteToBuffer(refreshRoom->roomExternalInfo.attributes[i], buffer);
			}
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomInternalInfoUpdated )
		{
			buffer.WriteUInt64(refreshRoom->roomInternalInfo.numAttributes);

			for(int i = 0; i < refreshRoom->roomInternalInfo.numAttributes; i++)
			{
				WriteToBuffer(refreshRoom->roomInternalInfo.attributes[i], buffer);
			}

			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.allowBlockedUsersOfMembers);
			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.joinAllLocalUsers);
			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.isNatRestricted);
			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.numReservedSlots);
			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.visibility);
			buffer.WriteUInt32((UInt32)refreshRoom->roomInternalInfo.closeRoom);		
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomSessionInfoUpdated )
		{
			buffer.WriteUInt32((UInt32)refreshRoom->roomSessionInfo.displayOnSystem);
			buffer.WriteUInt32((UInt32)refreshRoom->roomSessionInfo.isSystemJoinable);
			buffer.WriteUInt32((UInt32)refreshRoom->roomSessionInfo.hasChangeableData);

			WriteToBuffer(refreshRoom->roomSessionInfo.boundSessionId, buffer);
		}
		else if ( refreshRoom->reason ==  NpToolkit2::Matching::Notification::Reason::roomTopologyUpdated )
		{
			buffer.WriteUInt32((UInt32)refreshRoom->roomTopology);
		}

		buffer.WriteMarker(BufferIntegrityChecks::RefreshRoomEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalInvitationReceived(NptInvitationReceivedResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptInvitationReceived* invitationReceived = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::InvitationReceivedBegin);

		Core::WriteToBuffer(invitationReceived->localUpdatedUser, buffer);
		Core::WriteToBuffer(invitationReceived->remoteUser, buffer);

		buffer.WriteUInt32((UInt32)invitationReceived->platform);

		buffer.WriteMarker(BufferIntegrityChecks::InvitationReceivedEnd);

		SUCCESS_RESULT(result);
	}

	void Matching::MarshalNewRoomMessage(NptNewRoomMessageResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptNewRoomMessage* newRoomMessage = response->get();
		
		buffer.WriteMarker(BufferIntegrityChecks::NewRoomMessageBegin);

		buffer.WriteUInt64(newRoomMessage->roomId); // SceNpMatching2RoomId

		buffer.WriteData(newRoomMessage->data, newRoomMessage->dataSize);

		buffer.WriteUInt16(newRoomMessage->sender); // SceNpMatching2RoomMemberId

		buffer.WriteBool(newRoomMessage->isChatMsg);
		buffer.WriteBool(newRoomMessage->isFiltered);
						
		buffer.WriteMarker(BufferIntegrityChecks::NewRoomMessageEnd);

		SUCCESS_RESULT(result);

	}

	// System Events
	void Matching::HandleSessionInvitationEvent(SceNpSessionInvitationEventParam* eventParam)
	{
		// As this is a notification just create a Response class base class, and create a memory buffer for it, with the data in it. 
		// Then that can be added to the output queue event system.

		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();		
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::SessionInvitationEventBegin);

		WriteToBuffer(eventParam->sessionId, buffer);
		WriteToBuffer(eventParam->invitationId, buffer);

		buffer.WriteInt32(eventParam->flag);

		Core::WriteToBuffer(eventParam->onlineId, buffer);

		buffer.WriteInt32(eventParam->userId);

		Core::WriteToBuffer(eventParam->referralOnlineId, buffer);
		Core::WriteToBuffer(eventParam->referralAccountId, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::SessionInvitationEventEnd);

		buffer.FinishResponseWrite();

		CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended::notificationSessionInvitationEvent, buffer);
	}

	void Matching::HandlePlayTogetherHostEvent(SceNpPlayTogetherHostEventParamA* eventParam)
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();		
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::PlayTogetherHostEventBegin);

		buffer.WriteInt32(eventParam->userId);

		buffer.WriteUInt32(eventParam->inviteeListLen);
		
		for(int i = 0; i < eventParam->inviteeListLen; i++)
		{
			WriteToBuffer(eventParam->inviteeList[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::PlayTogetherHostEventEnd);

		buffer.FinishResponseWrite();

		CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended::notificationPlayTogetherHostEvent, buffer);
	}

	// Write method

	void Matching::WriteToBuffer(const SceNpPlayTogetherInvitee& invitee, MemoryBuffer& buffer)
	{
		Core::WriteToBuffer(invitee.accountId, buffer);
		Core::WriteToBuffer(invitee.onlineId, buffer);
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::World& world, MemoryBuffer& buffer)
	{
		buffer.WriteUInt32(world.worldId);
		buffer.WriteUInt32(world.currentNumberOfRooms);
		buffer.WriteUInt32(world.currentNumberOfMembers);
		buffer.WriteUInt16(world.worldNumber);
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::Room& room, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::RoomBegin);

		buffer.WriteUInt16(room.matchingContext); // SceNpMatching2ContextId
		buffer.WriteUInt16(room.serverId); // SceNpMatching2ServerId
		buffer.WriteUInt32(room.worldId); // SceNpMatching2WorldId

		buffer.WriteUInt64(room.roomId); // SceNpMatching2RoomId

		buffer.WriteUInt64(room.numAttributes);

		for(int i = 0; i < room.numAttributes; i++)
		{
			WriteToBuffer(room.attributes[i], buffer);
		}

		buffer.WriteString(room.name);

		buffer.WriteUInt64(room.numCurrentMembers);

		for(int i = 0; i < room.numCurrentMembers; i++)
		{
			WriteToBuffer(room.currentMembers[i], buffer);
		}

		buffer.WriteUInt64(room.numMaxMembers);
		buffer.WriteUInt32((UInt32)room.topology);
		buffer.WriteUInt32(room.numReservedSlots);

		buffer.WriteBool(room.isNatRestricted);
		buffer.WriteBool(room.allowBlockedUsersOfOwner);
		buffer.WriteBool(room.allowBlockedUsersOfMembers);
		buffer.WriteBool(room.joinAllLocalUsers);

		buffer.WriteUInt32((UInt32)room.ownershipMigration);
		buffer.WriteUInt32((UInt32)room.visibility);

		WriteToBuffer(room.password, buffer);

		WriteToBuffer(room.boundSessionId, buffer);

		buffer.WriteBool(room.isSystemJoinable);
		buffer.WriteBool(room.displayOnSystem);
		buffer.WriteBool(room.hasChangeableData);
		buffer.WriteBool(room.hasFixedData);
		buffer.WriteBool(room.isCrossplatform);
		buffer.WriteBool(room.isClosed);

		buffer.WriteMarker(BufferIntegrityChecks::RoomEnd);
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::Attribute& attribute, MemoryBuffer& buffer)
	{
		WriteToBuffer(attribute.metadata, buffer);
		
		if ( attribute.metadata.type == NpToolkit2::Matching::AttributeType::integer )
		{
			buffer.WriteInt32(attribute.intValue);
		}
		else if ( attribute.metadata.type == NpToolkit2::Matching::AttributeType::binary )
		{
			buffer.WriteData(attribute.binValue, NpToolkit2::Matching::Attribute::MAX_SIZE_BIN_VALUE);
		}
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::AttributeMetadata& metadata, MemoryBuffer& buffer)
	{
		buffer.WriteString(metadata.name);
		
		buffer.WriteUInt32((UInt32)metadata.type);
		buffer.WriteUInt32((UInt32)metadata.scope);
		buffer.WriteUInt32((UInt32)metadata.roomAttributeVisibility);
		buffer.WriteUInt32(metadata.size);
	}

	void Matching::WriteToBuffer(const SceNpSessionId& sessionId, MemoryBuffer& buffer)
	{
		//buffer.WriteData(sessionId.data, SCE_NP_SESSION_ID_MAX_SIZE);
		buffer.WriteString(sessionId.data);
	}

	void Matching::WriteToBuffer(const SceNpMatching2SessionPassword& password, MemoryBuffer& buffer)
	{
		buffer.WriteString((char*)password.data, SCE_NP_MATCHING2_SESSION_PASSWORD_SIZE);
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::Member& member, MemoryBuffer& buffer)
	{
		Core::WriteToBuffer(member.onlineUser, buffer);

		buffer.WriteUInt64(member.numMemberAttributes);

		for(int i = 0; i < member.numMemberAttributes; i++)
		{
			WriteToBuffer(member.memberAttributes[i], buffer);
		}

		Core::WriteToBuffer(member.joinedDate, buffer);

		WriteToBuffer(member.signalingInformation, buffer);

		buffer.WriteUInt32((UInt32)member.platform);  
		buffer.WriteUInt16((UInt32)member.roomMemberId);  

		buffer.WriteBool(member.isOwner);  
		buffer.WriteBool(member.isMe);  
	}

	void Matching::WriteToBuffer(const NpToolkit2::Matching::MemberSignalingInformation& signalingInformation, MemoryBuffer& buffer)
	{
		buffer.WriteUInt32((UInt32)signalingInformation.natType);             // SCE_NET_CTL_NATINFO_NAT_TYPE_XXX
		buffer.WriteUInt32((UInt32)signalingInformation.status); 
		buffer.WriteUInt32((UInt32)signalingInformation.roundTripTime); 

		NetworkUtils::WriteToBuffer(signalingInformation.ipAddress, buffer); 

		buffer.WriteUInt16(sceNetNtohs(signalingInformation.port)); // Host byte order
		buffer.WriteUInt16(signalingInformation.port);  // Network byte order
	}

	void Matching::WriteToBuffer(const SceNpMatching2PresenceOptionData& optionData, MemoryBuffer& buffer)
	{
		buffer.WriteData((char*)optionData.data, optionData.len);
	}

	void Matching::WriteToBuffer(const SceNpInvitationId& invitationId, MemoryBuffer& buffer)
	{
		buffer.WriteString(invitationId.data); 	// SCE_NP_INVITATION_ID_MAX_SIZE
	}
}
