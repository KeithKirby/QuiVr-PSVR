#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	struct VirtualUserIDManaged
	{
	public:
		char virtualUserID[SCE_NP_ONLINEID_MAX_LENGTH+1];

		void CopyTo(SceNpTusVirtualUserId &destination);
	};

	struct TusUserInputManaged
	{
	public:

		VirtualUserIDManaged virtualId;				///< The ID of a virtual user. This is only used if <c><i>isVirtualUser</i></c> is set to <c>true</c>.
		SceNpAccountId realId;							///< The account ID of the user whose data needs to be deleted.								
		bool isVirtual;									///< A flag that specifies whether this is a virtual user.

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		void CopyTo(NpToolkit2::TUS::Request::TusUserInput &destination);
#endif
	};

	struct TusVariableInputManaged
	{
	public:
		Int64			value;			///< The TUS variable value
		SceNpTusSlotId	slotId;			///< The slot that the variable belongs to

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		void CopyTo(NpToolkit2::TUS::Request::TusVariableInput &destination);
#else
		void CopyTo(NpToolkit2::TUS::TusVariable &destination);
#endif
	};

	class TusSetVariablesManaged : public RequestBaseManaged
	{
	public:

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	const static int32_t MAX_VARIABLE_SLOTS = NpToolkit2::TUS::Request::SetVariables::MAX_VARIABLE_VIRTUAL_SLOTS;
#else
	const static int32_t MAX_VARIABLE_SLOTS = 256;
#endif

		TusUserInputManaged		tusUser;
		UInt64 numVars;
		TusVariableInputManaged	variables[MAX_VARIABLE_SLOTS];	///< The TUS variables to update
		
		void CopyTo(NpToolkit2::TUS::Request::SetVariables &destination);
	};	

	class TusGetVariablesManaged : public RequestBaseManaged
	{
	public:

		const static int32_t MAX_VARIABLE_SLOTS = TusSetVariablesManaged::MAX_VARIABLE_SLOTS;

		TusUserInputManaged		tusUser;
		UInt64 numSlots;
		SceNpTusSlotId slots[MAX_VARIABLE_SLOTS];	///< The TUS variables to update
		bool forCrossSave;

		void CopyTo(NpToolkit2::TUS::Request::GetVariables &destination);
	};	

	struct TusDataContentionManaged
	{
		SceRtcTick		lastChangedDate;
		SceNpAccountId	requiredLastChangeUser;	

		void CopyTo(NpToolkit2::TUS::DataContention &destination);
	};

	class TusAddToAndGetVariableManaged : public RequestBaseManaged
	{
	public:
		TusUserInputManaged		tusUser;
		TusVariableInputManaged var;
		TusDataContentionManaged dataContention;
		bool forCrossSave;

		void CopyTo(NpToolkit2::TUS::Request::AddToAndGetVariable &destination);
	};

	class TusSetDataManaged : public RequestBaseManaged
	{
	public:

		TusUserInputManaged		tusUser;
		void *data;
		UInt64 dataSize;
		UInt64 supplementaryInfoSize;	
		char supplementaryInfo[SCE_NP_TUS_DATA_INFO_MAX_SIZE];	//< Supplementary Information for the TUS Data
		TusDataContentionManaged dataContention;
		SceNpTusSlotId	slotId;

		void CopyTo(NpToolkit2::TUS::Request::SetData &destination);
	};

	class TusGetDataManaged : public RequestBaseManaged
	{
	public:

		TusUserInputManaged		tusUser;
		SceNpTusSlotId	slotId;
		bool forCrossSave;
		bool retrieveStatusOnly;
		
		void CopyTo(NpToolkit2::TUS::Request::GetData &destination);
	};

	class TusDeleteDataManaged : public RequestBaseManaged
	{
	public:

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	const static int32_t MAX_DATA_SLOTS = NpToolkit2::TUS::Request::DeleteData::MAX_DATA_VIRTUAL_SLOTS;
#else
	const static int32_t MAX_DATA_SLOTS = 64;
#endif
		TusUserInputManaged tusUser;

		UInt64 numSlots;
		SceNpTusSlotId slots[MAX_DATA_SLOTS];	///< The IDs of the slots that you want to delete

		void CopyTo(NpToolkit2::TUS::Request::DeleteData &destination);
	};

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)

	class TusTryAndSetVariableManaged : public RequestBaseManaged
	{
	public:

		TusUserInputManaged tusUser;
		TusVariableInputManaged varToUpdate;
		TusDataContentionManaged dataContention;

		Int64 compareValue;
		NpToolkit2::TUS::TryAndSetCompareOperator compareOperator;
		bool forCrossSave;

		void CopyTo(NpToolkit2::TUS::Request::TryAndSetVariable &destination);
		NpToolkit2::TUS::TryAndSetCompareOperator ConvertOperator(NpToolkit2::TUS::TryAndSetCompareOperator compareOp);
	};

	class TusGetFriendsVariableManaged : public RequestBaseManaged
	{
	public:

		UInt32 pageSize;
		SceNpTusSlotId slotId;		
		NpToolkit2::TUS::FriendsVariableSortingOrder sortingOrder;
		UInt32 startIndex;		
		bool forCrossSave;	
		bool includeMeIfFound;	

		void CopyTo(NpToolkit2::TUS::Request::GetFriendsVariable &destination);
	};

	class TusGetUsersVariableManaged : public RequestBaseManaged
	{
	public:

		UInt32 maxUsersToObtain;							///< The maximum number of users' variables to obtain. 

		VirtualUserIDManaged virtualUsersIds[NpToolkit2::TUS::Request::GetUsersVariable::MAX_NUM_USERS];
		SceNpAccountId realUsersIds[NpToolkit2::TUS::Request::GetUsersVariable::MAX_NUM_USERS];

		SceNpTusSlotId slotId;						
		bool areVirtualUsers;
		bool forCrossSave;

		void CopyTo(NpToolkit2::TUS::Request::GetUsersVariable &destination);
	};

	class TusGetUsersDataStatusManaged : public RequestBaseManaged
	{
	public:

		UInt32 maxUsersToObtain;							///< The maximum number of users' variables to obtain. 

		VirtualUserIDManaged virtualUsersIds[NpToolkit2::TUS::Request::GetUsersDataStatus::MAX_NUM_USERS];
		SceNpAccountId realUsersIds[NpToolkit2::TUS::Request::GetUsersDataStatus::MAX_NUM_USERS];

		SceNpTusSlotId slotId;						
		bool areVirtualUsers;
		bool forCrossSave;

		void CopyTo(NpToolkit2::TUS::Request::GetUsersDataStatus &destination);
	};

	class TusGetFriendsDataStatusManaged : public RequestBaseManaged
	{
	public:

		UInt32 pageSize;
		SceNpTusSlotId					slotId;
		NpToolkit2::TUS::FriendsDataStatusSortingOrder	sortingOrder;
		UInt32						    startIndex;
		bool							forCrossSave;
		bool							includeMeIfFound;

		void CopyTo(NpToolkit2::TUS::Request::GetFriendsDataStatus &destination);
	};
#endif

	class TUS
	{
	public:

		typedef NpToolkit2::TUS::TusVariables NptTusVariables;
		typedef NpToolkit2::Core::Response<NptTusVariables> NptTusVariablesResponse;

#if (SCE_ORBIS_SDK_VERSION < 0x05000000)
		typedef NpToolkit2::TUS::AtomicAddToAndGetVariable NptAtomicAddToAndGetVariable;
		typedef NpToolkit2::Core::Response<NptAtomicAddToAndGetVariable> NptAtomicAddToAndGetVariableResponse;
#endif

		typedef NpToolkit2::TUS::TusData NptTusData;
		typedef NpToolkit2::Core::Response<NptTusData> NptTusDataResponse;

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		typedef NpToolkit2::TUS::FriendsVariables NptTusFriendsVariables;
		typedef NpToolkit2::Core::Response<NptTusFriendsVariables> NptTusFriendsVariablesResponse;

		typedef NpToolkit2::TUS::TusDataStatuses NptTusDataStatuses;
		typedef NpToolkit2::Core::Response<NptTusDataStatuses> NptTusDataStatusesResponse;

		typedef NpToolkit2::TUS::FriendsDataStatuses NptTusFriendsDataStatuses;
		typedef NpToolkit2::Core::Response<NptTusFriendsDataStatuses> NptTusFriendsDataStatusesResponse;
#endif

		//Requests
		static int SetVariables(TusSetVariablesManaged* managedRequest, APIResult* result);
		static int GetVariables(TusGetVariablesManaged* managedRequest, APIResult* result);
		static int AddToAndGetVariable(TusAddToAndGetVariableManaged* managedRequest, APIResult* result);
		static int SetData(TusSetDataManaged* managedRequest, APIResult* result);
		static int GetData(TusGetDataManaged* managedRequest, APIResult* result);
		static int DeleteData(TusDeleteDataManaged* managedRequest, APIResult* result);

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		static int TryAndSetVariable(TusTryAndSetVariableManaged* managedRequest, APIResult* result);
		static int GetFriendsVariable(TusGetFriendsVariableManaged* managedRequest, APIResult* result);
		static int GetUsersVariable(TusGetUsersVariableManaged* managedRequest, APIResult* result);
		static int GetUsersDataStatus(TusGetUsersDataStatusManaged* managedRequest, APIResult* result);
		static int GetFriendsDataStatus(TusGetFriendsDataStatusManaged* managedRequest, APIResult* result);

		static void WriteToBuffer(const NptTusDataStatuses& sceNpTusDataStatus, MemoryBuffer& buffer);
#endif

		// Marshal methods
		static void MarshalTusVariables(NptTusVariablesResponse* response, MemoryBuffer& buffer, APIResult* result);

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		static void MarshalTusFriendsVariable(NptTusFriendsVariablesResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalTusDataStatuses(NptTusDataStatusesResponse* response, MemoryBuffer& buffer, APIResult* result);	
		static void MarshalTusFriendsDataStatusesResponse(NptTusFriendsDataStatusesResponse* response, MemoryBuffer& buffer, APIResult* result);
#endif

#if (SCE_ORBIS_SDK_VERSION < 0x05000000)
		static void MarshalAtomicAddToAndGetVariable(NptAtomicAddToAndGetVariableResponse* response, MemoryBuffer& buffer, APIResult* result);
#endif

		static void MarshalTusData(NptTusDataResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Write Methods
		static void WriteToBuffer(const SceNpTusVariableA& sceNpTusVariable, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTusVariableForCrossSave& sceNpTusVariable, MemoryBuffer& buffer);
	
	#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		static void WriteToBuffer(const NpToolkit2::TUS::TusDataStatus& tusDataStatus, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::TUS::TusDataStatusForCrossSave& tusDataStatusForCrossSave, MemoryBuffer& buffer);
	#else
		static void WriteToBuffer(const SceNpTusDataStatusA& sceNpTusDataStatus, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTusDataStatusForCrossSave& sceNpTusDataStatusForCrossSave, MemoryBuffer& buffer);
	#endif

	};
}





