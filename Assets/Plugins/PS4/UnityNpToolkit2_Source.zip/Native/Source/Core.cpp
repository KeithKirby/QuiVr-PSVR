
#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxTerminateService ) (TerminateServiceManaged* managedRequest, APIResult* result)
	{
		return Core::TerminateService(managedRequest, result);
	}

	void TerminateServiceManaged::CopyTo(NpToolkit2::Core::Request::TerminateService &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.service = service;
	}

	int Core::TerminateService(TerminateServiceManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Core::Request::TerminateService nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Core::terminateService(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void Core::WriteToBuffer(const NpToolkit2::Core::OnlineUser& onLineUser, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserBegin);

		buffer.WriteUInt64(onLineUser.accountId);
		WriteToBuffer(onLineUser.onlineId, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserEnd);
	}

	void Core::WriteToBuffer(const SceNpOnlineId& onLineId, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NpOnlineIdBegin);

		buffer.WriteData(onLineId.data, SCE_NP_ONLINEID_MAX_LENGTH);

		buffer.WriteMarker(BufferIntegrityChecks::NpOnlineIdEnd);
	}

	void Core::WriteToBuffer(const SceNpAccountId& accountId, MemoryBuffer& buffer)
	{
		buffer.WriteUInt64(accountId);
	}

	void Core::WriteToBuffer(const SceNpId& npId, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::SceNpIdBegin);

		WriteToBuffer(npId.handle, buffer);

		buffer.WriteData((char*)npId.opt, 8);

		buffer.WriteMarker(BufferIntegrityChecks::SceNpIdEnd);
	}

	void Core::WriteToBuffer(const SceNpCountryCode& countryCode, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NpCountryCodeBegin);

		buffer.WriteString(countryCode.data, SCE_NP_COUNTRY_CODE_LENGTH);

		buffer.WriteMarker(BufferIntegrityChecks::NpCountryCodeEnd);
	}

	void Core::WriteToBuffer(const SceNpTitleId& titleId, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NpTitleIdBegin);
		buffer.WriteString(titleId.id, SCE_NP_TITLE_ID_LEN);
		buffer.WriteMarker(BufferIntegrityChecks::NpTitleIdEnd);
	}

	void Core::WriteToBuffer(const SceNpLanguageCode& languageCode, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::NpLanguageCodeBegin);
		buffer.WriteString(languageCode.code, SCE_NP_LANGUAGE_CODE_MAX_LEN);
		buffer.WriteMarker(BufferIntegrityChecks::NpLanguageCodeEnd);
	}

	void Core::WriteToBuffer(const SceRtcTick& ticks, MemoryBuffer& buffer)
	{
		// Important : 	Sce ticks are microsecond, .net are 100 nanosecond. This conversion
		// will be done in the C# read method
		buffer.WriteUInt64(ticks.tick);
	}

	void Core::CopyServerError(NpToolkit2::Core::ServerError& destination, const NpToolkit2::Core::ServerError& source)
	{
		memcpy(destination.jsonData, source.jsonData, NpToolkit2::Core::ServerError::JSON_DATA_MAX_LEN);
		destination.webApiNextAvailableTime = source.webApiNextAvailableTime;
		destination.httpStatusCode = source.httpStatusCode;
	}

	void Core::CopyResponseBase(NpToolkit2::Core::ResponseBase& destination, NpToolkit2::Core::ResponseBase& source)
	{
		destination.setReturnCode(source.getReturnCode());

		if ( source.getServerError() != NULL )
		{
			NpToolkit2::Core::ServerError* newError = new NpToolkit2::Core::ServerError();
			destination.setServerError(newError);
			CopyServerError(*newError, *source.getServerError());
		}
	}

	/// Get an empty response object
	//  This handles and Response object that uses NpToolkit2::Core::Empty.
	// Even though the template class doesn't have any data the Response class may still contain server error and status information
	// in its ResponseBase class
	void Core::MarshalEmpty(NptEmptyResponse* emptyResponse, MemoryBuffer& buffer, APIResult* result)
	{
		SUCCESS_RESULT(result);
	}

	


	// PNG Writer
	void PNGWriter::SwapBytes(short* val)
	{
		char* bytes = (char*)val;
		char tmp = bytes[0]; bytes[0] = bytes[1]; bytes[1] = tmp;
	}

	void PNGWriter::SwapEndian(int* val)
	{
		short* words = (short*)val;
		short tmp = words[0]; words[0] = words[1]; words[1] = tmp;
		SwapBytes(&words[0]);
		SwapBytes(&words[1]);
	}

	void PNGWriter::WriteToBuffer(const void* iconData, Int32 size,  MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::PNGBegin);
		if ( iconData == NULL )
		{
			buffer.WriteBool(false); // No icon exists
		}
		else
		{
			buffer.WriteBool(true); // Icon exists
			buffer.WriteInt32(size);

			PNG* png = (PNG*)iconData;
			IHDR* header = (IHDR*)(png+1);
			int width = header->width;
			int height = header->height;
			SwapEndian(&width);
			SwapEndian(&height);

			buffer.WriteInt32(width);
			buffer.WriteInt32(height);
			buffer.WriteData((char*)png, size);
		}

		buffer.WriteMarker(BufferIntegrityChecks::PNGEnd);
	}
}
