
#include "Init.h"

#include <string>

namespace NPT
{
	SceUserServiceUserId Init::s_PrimaryUserId = 0;

	void Init::InitializeToolkitInternal(InitToolkit& init, InitResult& initResult, NpToolkit2::Core::NpToolkitCallback npToolkitCallback,  APIResult* result)
	{
		int ret = 0;

		SceUserServiceUserId userId = 0;
		ret = sceUserServiceGetInitialUser(&userId);
		if (ret < 0 )
		{
			// SCE_USER_SERVICE_ERROR_OPERATION_NOT_SUPPORTED = this means the "User Management" tickbox in the editor has been selected and the "Initial User Always Logged In" flag is disabled. There might not be a default user logged in.
			if (ret != SCE_USER_SERVICE_ERROR_OPERATION_NOT_SUPPORTED) 
			{
				SCE_ERROR_RESULT(result, ret);
				return;
			}
		}

		s_PrimaryUserId = userId;

		//init core
		NpToolkit2::Core::Request::InitParams initParams;

		// Standard Nptoolkit params not controllable from C# 
		initParams.externalAlloc.allocate = malloc;
		initParams.externalAlloc.deallocate = free;

		initParams.memPools.npToolkitPoolSize = init.memPools.npToolkitPoolSize;
		initParams.memPools.jsonPoolSize = init.memPools.jsonPoolSize;
		initParams.memPools.webApiPoolSize = init.memPools.webApiPoolSize;
		initParams.memPools.httpPoolSize = init.memPools.httpPoolSize;
		initParams.memPools.sslPoolSize = init.memPools.sslPoolSize;
		initParams.memPools.netPoolSize = init.memPools.netPoolSize;
		initParams.memPools.matchingPoolSize = init.memPools.matchingPoolSize;
		initParams.memPools.matchingSslPoolSize = init.memPools.matchingSslPoolSize;
		initParams.memPools.inGameMessagePoolSize = init.memPools.inGameMessagePoolSize;

		initParams.npToolkitCallbackInfo.callback = npToolkitCallback;

		initParams.defaultRequestParams.defaultUserId = userId; //no longer need to set the User Id in the Request object of any call
		initParams.defaultRequestParams.defaultServiceLabel = 0; //no longer need to set the Service Label in the Request object of any call
		initParams.defaultRequestParams.defaultAsync = true; //no longer need to set the Async member in the Request object of any call

		// Paramters initialised from the C# settings
        if ( init.pushNotificationFlagsSet == true )
        {
            initParams.serverPushNotifications.newGameDataMessage = init.pushNotificationFlags & ServerPushNotificationsFlags::newGameDataMessage;
		    initParams.serverPushNotifications.newInvitation  = init.pushNotificationFlags & ServerPushNotificationsFlags::newInvitation;
		    initParams.serverPushNotifications.updateBlockedUsersList = init.pushNotificationFlags & ServerPushNotificationsFlags::updateBlockedUsersList;
		    initParams.serverPushNotifications.updateFriendPresence = init.pushNotificationFlags & ServerPushNotificationsFlags::updateFriendPresence;
		    initParams.serverPushNotifications.updateFriendsList = init.pushNotificationFlags & ServerPushNotificationsFlags::updateFriendsList;
		    initParams.serverPushNotifications.newInGameMessage = init.pushNotificationFlags & ServerPushNotificationsFlags::newInGameMessage;
        }
        else
        {
		    initParams.serverPushNotifications.newGameDataMessage = init.serverPushNotifications.newGameDataMessage;
		    initParams.serverPushNotifications.newInvitation  = init.serverPushNotifications.newInvitation;
		    initParams.serverPushNotifications.updateBlockedUsersList = init.serverPushNotifications.updateBlockedUsersList;
		    initParams.serverPushNotifications.updateFriendPresence = init.serverPushNotifications.updateFriendPresence;
		    initParams.serverPushNotifications.updateFriendsList = init.serverPushNotifications.updateFriendsList;
		    initParams.serverPushNotifications.newInGameMessage = init.serverPushNotifications.newInGameMessage;
        }

		initParams.threadProperties.affinity = init.threadSettings.affinityFlags;

		// Remove bits 0 and 1 from the affinty mask. This shouldn't be necessary as the C# init method should throw an exception if they are set.
		initParams.threadProperties.affinity &= ~0x3; 

		NpRequests::SetCurrentCpuMask(initParams.threadProperties.affinity);

		//initParams.threadProperties.affinity = 0<<0 |    // ignore core0 (MainLoop)
		//									   0<<1 |    // ignore core1 (UnityGfxDeviceWorker)
		//									   1<<2 |
		//									   1<<3 |
		//									   1<<4 |
		//									   1<<5;

		//init toolkit lib core
		ret = NpToolkit2::Core::init(initParams);

		if (ret == SCE_TOOLKIT_NP_V2_ERROR_ALREADY_INITIALIZED)
		{
			SCE_ERROR_RESULT(result, ret);
			return;
		}
		else if (ret < 0)
		{
			SCE_ERROR_RESULT(result,ret);
			return;
		}

		if ( InitializeAgeRatingsInternal(init.contentRestrictions, result) == false )
		{
			// result will be set to an error code
			return;
		} 

        if ( init.pushNotificationFlagsSet == true )
        {
		    SUCCESS_RESULT(result);
        }
        else
        {
            ERROR_RESULT(result, "Make sure SetPushNotificationsFlags is called before calling Sony.NP.Main.Initialize. Must not use deprecated push notification settings.");
        }

		initResult.initialized = true;
		initResult.sceSDKVersion = SCE_ORBIS_SDK_VERSION;
	}

	bool Init::InitializeAgeRatingsInternal(ContentRestriction& restriction, APIResult* result)
	{
		if ( restriction.applyContentRestriction == false )
		{
			return true;
		}

		SceNpContentRestriction npContentRestriction;
		npContentRestriction.size						= sizeof( SceNpContentRestriction );
		npContentRestriction.defaultAgeRestriction		= restriction.defaultAgeRestriction;

		if ( restriction.numAgeRestictions == 0 )
		{
			npContentRestriction.ageRestrictionCount = 0;
			npContentRestriction.ageRestriction = NULL;
		}
		else
		{
			int numAgeRestictions = restriction.numAgeRestictions;
			if ( numAgeRestictions > MAX_AGE_RESTRICTIONS)
			{
				numAgeRestictions = MAX_AGE_RESTRICTIONS;
			}
			npContentRestriction.ageRestrictionCount = numAgeRestictions;
			npContentRestriction.ageRestriction = s_ageRestriction;

			for(int i = 0; i < numAgeRestictions; i++)
			{
				strncpy(s_ageRestriction[i].countryCode.data, restriction.ageRestrictions[i].countryCode, 2);
				s_ageRestriction[i].age = restriction.ageRestrictions[i].age;
			}
		}

		int ret = sceNpSetContentRestriction(&npContentRestriction);
		if (ret < 0)
		{
			SCE_ERROR_RESULT(result,ret);
			return false;
		}

		SUCCESS_RESULT(result);
		return true;
	}

	SceNpAgeRestriction Init::s_ageRestriction[MAX_AGE_RESTRICTIONS];
}
