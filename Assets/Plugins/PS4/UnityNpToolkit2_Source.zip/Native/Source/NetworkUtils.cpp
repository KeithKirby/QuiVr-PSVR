
#include "NetworkUtils.h"

#include "Core.h"

namespace NPT
{
	// PRX exports
	DO_EXPORT( int, PrxGetBandwidthInfo ) (GetBandwidthInfoManaged* managedRequest, APIResult* result)
	{
		return NetworkUtils::GetBandwidthInfo(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetBasicNetworkInfo ) (GetBasicNetworkInfoManaged* managedRequest, APIResult* result)
	{
		return NetworkUtils::GetBasicNetworkInfo(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetDetailedNetworkInfo ) (GetDetailedNetworkInfoManaged* managedRequest, APIResult* result)
	{
		return NetworkUtils::GetDetailedNetworkInfo(managedRequest, result);
	}

	// Managed Request marshal structures
	void GetBandwidthInfoManaged::CopyTo(NpToolkit2::NetworkUtils::Request::GetBandwidthInfo &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		// The GetBandwidthInfo request class is currenly emoty and contains no additional members other than those in the base class
	}

	void GetBasicNetworkInfoManaged::CopyTo(NpToolkit2::NetworkUtils::Request::GetBasicNetworkInfo &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		// The GetBasicNetworkInfo request class is currenly emoty and contains no additional members other than those in the base class
	}

	void GetDetailedNetworkInfoManaged::CopyTo(NpToolkit2::NetworkUtils::Request::GetDetailedNetworkInfo &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		// The GetDetailedNetworkInfo request class is currenly emoty and contains no additional members other than those in the base class
	}

	// Request methods
	int NetworkUtils::GetBandwidthInfo(GetBandwidthInfoManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptBandwidthInfoResponse* nptResponse = new NptBandwidthInfoResponse();

		NpToolkit2::NetworkUtils::Request::GetBandwidthInfo nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NetworkUtils::getBandwidthInfo(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int NetworkUtils::GetBasicNetworkInfo(GetBasicNetworkInfoManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptNetStateBasicResponse* nptResponse = new NptNetStateBasicResponse();

		NpToolkit2::NetworkUtils::Request::GetBasicNetworkInfo nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NetworkUtils::getBasicNetworkInfo(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int NetworkUtils::GetDetailedNetworkInfo(GetDetailedNetworkInfoManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptNetStateDetailedResponse* nptResponse = new NptNetStateDetailedResponse();

		NpToolkit2::NetworkUtils::Request::GetDetailedNetworkInfo nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::NetworkUtils::getDetailedNetworkInfo(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	} 


	// Marshal methods
	void NetworkUtils::MarshalBandwidthInfo(NptBandwidthInfoResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptBandwidthInfo* bandwidthInfo = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::BandwidthInfoBegin);

		WriteToBuffer(bandwidthInfo->bandwidth, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::BandwidthInfoEnd);

		SUCCESS_RESULT(result);
	}

	void NetworkUtils::MarshalNetStateBasic(NptNetStateBasicResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptNetStateBasic* netStateBasic = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::NetStateBasicBegin);

		buffer.WriteString(netStateBasic->ipAddress, SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The IP address of the network adapter

		WriteToBuffer(netStateBasic->natInfo, buffer); 

		buffer.WriteUInt32(netStateBasic->connectionStatus);      // ///< The connection status. This maps to <c>SCE_NET_CTL_STATE_XXX</c>								

		buffer.WriteMarker(BufferIntegrityChecks::NetStateBasicEnd);

		SUCCESS_RESULT(result);
	}

	void NetworkUtils::MarshalNetStateDetailed(NptNetStateDetailedResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptNetStateDetailed* netStateDetailed = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::NetStateDetailedBegin);

		// Most of this data is bassed on SceNetCtlInfo 

		// Write natInfo                                             ///< The NAT type
		WriteToBuffer(netStateDetailed->natInfo, buffer);

		buffer.WriteUInt32(netStateDetailed->connectionStatus);      ///< The connection status. This maps to <c>SCE_NET_CTL_STATE_XXX</c>
		buffer.WriteUInt32(netStateDetailed->device);                ///< The network device being used SCE_NET_CTL_DEVICE_XXX

		WriteToBuffer(netStateDetailed->ethernetAddress, buffer);    ///< The MAC address

		buffer.WriteUInt8(netStateDetailed->rssiPercentage);        ///< The signal strength
		buffer.WriteUInt8(netStateDetailed->channel);               ///< The wireless channel used
		buffer.WriteUInt32(netStateDetailed->mtu);                   ///< MTU
		buffer.WriteUInt32(netStateDetailed->link);					 ///< The link connection state   SCE_NET_CTL_LINK_XXX
		buffer.WriteUInt32(netStateDetailed->wifiSecurity);          ///< Specifies whether wireless LAN is encrypted  SCE_NET_CTL_WIFI_SECURITY_XXX
		buffer.WriteUInt32(netStateDetailed->ipConfig);              ///< Specifies how the IP address is configured   SCE_NET_CTL_IP_XXX
		buffer.WriteUInt32(netStateDetailed->httpProxyConfig);       ///< The configuration of the proxy server    SCE_NET_CTL_HTTP_PROXY_XXX
		buffer.WriteUInt16(netStateDetailed->httpProxyPort);         ///< The proxy server port address						

		WriteToBuffer(netStateDetailed->bssid, buffer);            	///< BSSID

		buffer.WriteString(netStateDetailed->ssid,SCE_NET_CTL_SSID_LEN); ///< SSID
		buffer.WriteString(netStateDetailed->dhcpHostname,SCE_NET_CTL_HOSTNAME_LEN); ///< The DHCP hostname
		buffer.WriteString(netStateDetailed->pppoeAuthName,SCE_NET_CTL_AUTH_NAME_LEN); ///< The PPPOE authentication name
		buffer.WriteString(netStateDetailed->ipAddress,SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The devices IP address
		buffer.WriteString(netStateDetailed->netmask,SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The devices Net mask
		buffer.WriteString(netStateDetailed->defaultRoute,SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The default route IP address
		buffer.WriteString(netStateDetailed->primaryDNS,SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The primary domain name server IP address
		buffer.WriteString(netStateDetailed->secondaryDNS,SCE_NET_CTL_IPV4_ADDR_STR_LEN); ///< The secondary domain name server IP address
		buffer.WriteString(netStateDetailed->httpProxyServer,SCE_NET_CTL_HOSTNAME_LEN); ///< The IP address of the proxy

		buffer.WriteMarker(BufferIntegrityChecks::NetStateDetailedEnd);

		SUCCESS_RESULT(result);
	}

	void NetworkUtils::WriteToBuffer(const SceNpBandwidthTestResult& sceNpBandwidthTestResult, MemoryBuffer& buffer)
	{
		buffer.WriteDouble(sceNpBandwidthTestResult.uploadBps);
		buffer.WriteDouble(sceNpBandwidthTestResult.downloadBps);
		buffer.WriteInt32(sceNpBandwidthTestResult.result);
	}

	void NetworkUtils::WriteToBuffer(const SceNetCtlNatInfo& sceNetCtlNatInfo, MemoryBuffer& buffer)
	{
		// Write natInfo                                              ///< The NAT type
		//buffer.WriteUInt32(sceNetCtlNatInfo.size);             // Size of the structure - doesn't need to be written
		buffer.WriteInt32(sceNetCtlNatInfo.stunStatus);          // SCE_NET_CTL_NATINFO_STUN_XXX
		buffer.WriteInt32(sceNetCtlNatInfo.natType);             // SCE_NET_CTL_NATINFO_NAT_TYPE_XXX

		WriteToBuffer(sceNetCtlNatInfo.mappedAddr, buffer); 
	}

	void NetworkUtils::WriteToBuffer(const SceNetInAddr& cceNetInAddr, MemoryBuffer& buffer)
	{
		buffer.WriteUInt32(cceNetInAddr.s_addr); 
	}

	void NetworkUtils::WriteToBuffer(const SceNetEtherAddr& sceNetEtherAddr, MemoryBuffer& buffer)
	{                                    
		buffer.WriteData((char*)sceNetEtherAddr.data,SCE_NET_ETHER_ADDR_LEN);
	}

	// Notification Responses
	void NetworkUtils::MarshalNetStateChange(NptNetStateChangeResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptNetStateChange* netStateChange = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::NetStateChangeBegin);

		buffer.WriteUInt32(netStateChange->event); 

		buffer.WriteMarker(BufferIntegrityChecks::NetStateChangeEnd);

		SUCCESS_RESULT(result);
	}
}
