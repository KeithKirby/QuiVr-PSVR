#include <stdio.h>

#include "Presence.h"

namespace NPT
{
	DO_EXPORT( int, PrxDeletePresence ) (DeletePresenceManaged* managedRequest, APIResult* result)
	{
		return Presence::DeletePresence(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetPresence ) (SetPresenceManaged* managedRequest, APIResult* result)
	{
		return Presence::SetPresence(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetPresence ) (GetPresenceManaged* managedRequest, APIResult* result)
	{
		return Presence::GetPresence(managedRequest, result);
	}


	void DeletePresenceManaged::CopyTo(NpToolkit2::Presence::Request::DeletePresence &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.deleteGameData = deleteGameData;
		destination.deleteGameStatus = deleteGameStatus;
	}

	void SetPresenceManaged::CopyTo(NpToolkit2::Presence::Request::SetPresence &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		strncpy(destination.defaultGameStatus, defaultGameStatus, NpToolkit2::Presence::Request::SetPresence::MAX_SIZE_DEFAULT_GAME_STATUS + 1);

		if ( numLocalizedGameStatuses == 0 )
		{
			destination.localizedGameStatuses = NULL;
			destination.numLocalizedGameStatuses = 0;
		}
		else
		{
			destination.localizedGameStatuses = new NpToolkit2::Presence::Request::LocalizedGameStatus[numLocalizedGameStatuses];
			for(int i = 0; i < numLocalizedGameStatuses; i++)
			{
				strncpy(destination.localizedGameStatuses[i].gameStatus, localizedGameStatuses[i].gameStatus, NpToolkit2::Presence::Request::LocalizedGameStatus::MAX_SIZE_LOCALIZED_GAME_STATUS + 1);
				strncpy(destination.localizedGameStatuses[i].languageCode.code, localizedGameStatuses[i].languageCode, SCE_NP_LANGUAGE_CODE_MAX_LEN+1);
				destination.localizedGameStatuses[i].languageCode.code[SCE_NP_LANGUAGE_CODE_MAX_LEN] = 0; // make sure langiage code is null terminated
			}

			destination.numLocalizedGameStatuses = numLocalizedGameStatuses;
		}

		if ( binaryGameDataSize > 0 )
		{
			memcpy(destination.binaryGameData, binaryGameData, binaryGameDataSize);
		}

		destination.binaryGameDataSize = binaryGameDataSize;
	}

	class SetPresenceCleanup : public RequestCleanup<NpToolkit2::Presence::Request::SetPresence>
	{
	public:

		SetPresenceCleanup(NpToolkit2::Presence::Request::SetPresence* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Presence::Request::SetPresence* request = GetRequest();

			if ( request->localizedGameStatuses != NULL )
			{
				delete[] request->localizedGameStatuses;
			}
		}
	};

	void GetPresenceManaged::CopyTo(NpToolkit2::Presence::Request::GetPresence &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.fromUser = fromUser;
		destination.inContext = inContext;
	}

	int Presence::DeletePresence(DeletePresenceManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Presence::Request::DeletePresence nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Presence::deletePresence(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Presence::SetPresence(SetPresenceManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Presence::Request::SetPresence* nptRequest = new NpToolkit2::Presence::Request::SetPresence();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Presence::setPresence(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		SetPresenceCleanup* cleanup = new SetPresenceCleanup(nptRequest);
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Presence::GetPresence(GetPresenceManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptPresenceResponse* nptResponse = new NptPresenceResponse();

		NpToolkit2::Presence::Request::GetPresence nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Presence::getPresence(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void Presence::WriteToBuffer(const NpToolkit2::Presence::PlatformPresence& npPlatformPresence, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::PlatformPresenceBegin);

		buffer.WriteUInt32((UInt32)npPlatformPresence.onlineStatusOnPlatform);
		buffer.WriteUInt32((UInt32)npPlatformPresence.platform);

		Core::WriteToBuffer(npPlatformPresence.npTitleId, buffer);

		buffer.WriteString(npPlatformPresence.npTitleName);
		buffer.WriteString(npPlatformPresence.gameStatus);

		buffer.WriteData(npPlatformPresence.binaryGameData, npPlatformPresence.binaryGameDataSize);

		buffer.WriteMarker(BufferIntegrityChecks::PlatformPresenceEnd);
	}

	void Presence::WriteToBuffer(const NpToolkit2::Presence::Presence& npPresence, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::PresenceBegin);

		Core::WriteToBuffer(npPresence.user, buffer);

		buffer.WriteUInt32((UInt32)npPresence.psnOnlineStatus);
		buffer.WriteUInt32((UInt32)npPresence.mostRelevantPlatform);

		buffer.WriteUInt32((UInt32)npPresence.numPlatforms);

		for(int i = 0; i < npPresence.numPlatforms; i++)
		{
			WriteToBuffer(npPresence.platforms[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::PresenceEnd);
	}

	void Presence::MarshalPresence(NptPresenceResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptPresence* presence = response->get();

		WriteToBuffer(*presence, buffer);
	}

	void Presence::MarshalPresenceUpdate(NptPresenceUpdateResponse* response, MemoryBuffer& buffer, APIResult* result)
	{	
		buffer.WriteMarker(BufferIntegrityChecks::PresenceUpdateBegin);

		const NptPresenceUpdate* presenceUpdate = response->get();

		Core::WriteToBuffer(presenceUpdate->localUpdatedUser, buffer);
		Core::WriteToBuffer(presenceUpdate->remoteUser, buffer);
		buffer.WriteInt32(presenceUpdate->userId);
		buffer.WriteUInt32((Int32)presenceUpdate->updateType);

		buffer.WriteString(presenceUpdate->gameStatus);
		buffer.WriteData(presenceUpdate->binaryGameData, presenceUpdate->binaryGameDataSize);
		buffer.WriteUInt32((Int32)presenceUpdate->platform);

		buffer.WriteMarker(BufferIntegrityChecks::PresenceUpdateEnd);

		SUCCESS_RESULT(result);
	}

}
