
#include "Threading.h"

namespace NPT
{
	int AtomicExchange(int volatile* i, int value)
	{
		return sceAtomicExchange32((int32_t*)i, (int32_t)value);
	}

	bool AtomicCompareExchange (int volatile* i, int newValue, int expectedValue)
	{
		return sceAtomicCompareAndSwap32(i, expectedValue, newValue) == expectedValue;
	}

	Mutex AsyncCallbackAutoLock::lock;
	Mutex ResponseMapAutoLock::lock;
}